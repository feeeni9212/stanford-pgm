function f = EmptyFactorStruct
% Dummy function for the factor struct.
%
% Copyright (C) Daphne Koller, Stanford Univerity, 2012

f = struct ('var', [], 'card', [], 'val', []);

end

